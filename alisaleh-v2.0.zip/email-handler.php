<?php 
    echo "Please use my contacts (phone numbers and email) to reach me at the moment, thank you :)";