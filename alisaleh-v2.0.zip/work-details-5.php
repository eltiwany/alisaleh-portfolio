<!DOCTYPE html>
<html lang="en">

<!-- Mirrored from ixtheme.netlify.app/zuman/work-details-5.html by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 10 Jan 2022 06:43:29 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>
    <meta charset="UTF-8">
    <title>Stainless Steel Chair</title>
</head>
<body>
    <div id="ajax-content" class="work-popup">
        <!-- start work-details wrapper -->
        <div class="container">
            <div class="row justify-content-center text-center">
                <div class="col-md-8">
                    <div class="work-info">
                        <h4>Stainless Steel Chair</h4>
                        <p>Experience Design</p>
                    </div>
                </div>
            </div>
            <div class="row justify-content-center text-center">
                <div class="col-md-3">
                    <div class="work-info-card">
                        <h6>Client</h6>
                        <p>Themeforest</p>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="work-info-card">
                        <h6>Link</h6>
                        <p><a href="#0"><span class="ion-android-attach"></span> View Project</a></p>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="work-info-card">
                        <h6>Date</h6>
                        <p>19 April 2018</p>
                    </div>
                </div>
            </div>
            <div class="row justify-content-center text-center">
                <div class="col-md-12">
                    <div class="work-image">
                        <img class="img-fluid" src="img/work_details_05.jpg" alt="">
                    </div>
                </div>
                <div class="col-md-8">
                    <div class="work-details">
                        <h4>About Project</h4>
                        <p>Consectetur adipisicing elit. Placeat iusto ea, reiciendis harum debitis rerum quia amet vel corporis dolor officia perferendis fuga voluptate repudiandae facere cupiditate, natus eveniet officiis labore molestiae ut. Nisi doloremque facilis beatae natus numquam rem, modi quibusdam harum neque fugit explicabo repudiandae consectetur dolore. Eligendi tempore repellendus eveniet ipsum sunt est pariatur quaerat! Cupiditate, ducimus.</p>
                    </div>
                </div>
            </div>
        </div>
        <!-- end work-details wrapper -->
    </div>
</body>

<!-- Mirrored from ixtheme.netlify.app/zuman/work-details-5.html by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 10 Jan 2022 06:43:31 GMT -->
</html>