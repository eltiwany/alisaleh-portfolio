<!-- ========  All JS Here ========  -->
<script src="js/vendor/jquery-1.12.4.min.js"></script>
<script src="js/ajax-mail.js"></script>
<script src="js/plugins.js"></script>
<script src="js/main.js"></script>
<script src="js/particles.min.js"></script>