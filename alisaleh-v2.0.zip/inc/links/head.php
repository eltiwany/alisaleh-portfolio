<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<head>
    <meta charset="utf-8">
    <meta name="description" content="Zuman - Creative Personal Portfolio">
    <meta name="keywords" content="Portfolio, Personal, Creatiev, Zuman, Html Template, Portfolio Template">
    <meta name="author" content="ixTheme">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Title -->
    <title>Ali (Abdulla) Saleh - Portfolio</title>
    <!-- Favicon -->
    <link href="img/favicon.png" type="image/png" rel="icon">

    <!-- All CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet" type="text/css">
    <link href="css/ionicons.css" rel="stylesheet" type="text/css">
    <link href="css/mobiriseicons.css" rel="stylesheet" type="text/css">
    <link href="css/owl.carousel.min.css" rel="stylesheet" type="text/css">
    <link href="css/splitting.css" rel="stylesheet" type="text/css">
    <link href="css/magnific-popup.css" rel="stylesheet" type="text/css">
    <link href="css/main.css" rel="stylesheet" type="text/css">
    <link href="css/responsive.css" rel="stylesheet" type="text/css">
</head>