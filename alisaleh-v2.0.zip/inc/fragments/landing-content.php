<!-- start landing content -->
<div class="landing_content text-center">
    <div class="container">
        <div class="row">
            <div class="col text-white cd-intro">
                <h5 class="title-slide-in" data-splitting>Hello, I'm</h5>
                <h1 class="title-slide-in" data-splitting>Ali Saleh</h1>
                <h4 class="title-slide-in" data-splitting>Computer Engineer and Full Stack Developer (Web/Mobile)</h4>
            </div>
        </div>
    </div>
</div>
<!-- end landing content -->