<footer>
    <a href="#top" class="go_top">
        <i class="ion-ios-arrow-thin-up"></i>
    </a>
    <!-- start social links -->
    <ul class="social_links">
    <li><a target="_blank" href="https://twitter.com/eltiwany"><span class="ion-social-twitter"></span></a></li>
                        <li><a target="_blank" href="https://instagram.com/eltiwany"><span class="ion-social-instagram-outline"></span></a></li>
                        <li><a target="_blank" href="https://www.linkedin.com/in/ali-saleh-b2020312a/"><span class="ion-social-linkedin"></span></a></li>
                        <li><a target="_blank" href="https://github.com/eltiwany"><span class="ion-social-github"></span></a></li>
    </ul>
    <p class="copyright">&copy; Copyright <?= date('Y'); ?> <span><a href="https://nafuutronics.com" target="_blank" rel="noopener noreferrer">Nafuutronics</a></span>. All Rights Reserved.</p>
</footer>