<div class="clients">
    <div class="row justify-content-center text-center">
        <div class="col-lg-10 client_items">
            <!-- section title -->
            <h2 class="section_title">Clients</h2>
            <div class="row no-gutters">
                <div class="col">
                    <img src="img/brand/kist.png" alt="Karume Institute of Science and Technology">
                    <img src="img/brand/zanislandcarhire.png" alt="Zan Island Car Hire">
                    <img src="img/brand/shipco.png" alt="SHIPCO">
                </div>
            </div>
        </div>
    </div>
</div>  